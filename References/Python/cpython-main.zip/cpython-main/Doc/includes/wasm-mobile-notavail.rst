.. include for modules that don't work on WASM or mobile platforms

.. availability:: not Android, not iOS, not WASI.

   This module is not supported on :ref:`mobile platforms <mobile-availability>`
   or :ref:`WebAssembly platforms <wasm-availability>`.
