:tocdepth: 1

.. _removed:

***************
Removed Modules
***************

The modules described in this chapter have been removed from the Python
standard library.  They are documented here to help people find replacements.


.. toctree::
   :maxdepth: 1

   aifc.rst
   asynchat.rst
   asyncore.rst
   audioop.rst
   cgi.rst
   cgitb.rst
   chunk.rst
   crypt.rst
   distutils.rst
   imghdr.rst
   imp.rst
   mailcap.rst
   msilib.rst
   nis.rst
   nntplib.rst
   ossaudiodev.rst
   pipes.rst
   smtpd.rst
   sndhdr.rst
   spwd.rst
   sunau.rst
   telnetlib.rst
   uu.rst
   xdrlib.rst
