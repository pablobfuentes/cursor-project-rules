Pending removal in Python 3.14
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* The ``ma_version_tag`` field in :c:type:`PyDictObject` for extension modules
  (:pep:`699`; :gh:`101193`).

* Creating :c:data:`immutable types <Py_TPFLAGS_IMMUTABLETYPE>` with mutable
  bases (:gh:`95388`).
