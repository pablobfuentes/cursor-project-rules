========
Requests
========


BaseOptionLatestDataRequest
---------------------------

.. autoclass:: alpaca.data.requests.BaseOptionLatestDataRequest


OptionBarsRequest
-----------------

.. autoclass:: alpaca.data.requests.OptionBarsRequest


OptionTradesRequest
-------------------

.. autoclass:: alpaca.data.requests.OptionTradesRequest


OptionLatestQuoteRequest
------------------------

.. autoclass:: alpaca.data.requests.OptionLatestQuoteRequest


OptionLatestTradeRequest
------------------------

.. autoclass:: alpaca.data.requests.OptionLatestTradeRequest


OptionSnapshotRequest
---------------------

.. autoclass:: alpaca.data.requests.OptionSnapshotRequest


OptionChainRequest
------------------

.. autoclass:: alpaca.data.requests.OptionChainRequest
