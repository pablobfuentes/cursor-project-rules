========
Requests
========


BaseStockLatestDataRequest
--------------------------

.. autoclass:: alpaca.data.requests.BaseStockLatestDataRequest


StockBarsRequest
----------------

.. autoclass:: alpaca.data.requests.StockBarsRequest


StockQuotesRequest
------------------

.. autoclass:: alpaca.data.requests.StockQuotesRequest


StockTradesRequest
------------------

.. autoclass:: alpaca.data.requests.StockTradesRequest


StockLatestQuoteRequest
-----------------------

.. autoclass:: alpaca.data.requests.StockLatestQuoteRequest


StockLatestTradeRequest
-----------------------

.. autoclass:: alpaca.data.requests.StockLatestTradeRequest


StockSnapshotRequest
--------------------

.. autoclass:: alpaca.data.requests.StockSnapshotRequest


MostActivesRequest
------------------

.. autoclass:: alpaca.data.requests.MostActivesRequest


MarketMoversRequest
-------------------

.. autoclass:: alpaca.data.requests.MarketMoversRequest
