============
Screener API
============

ScreenerClient
--------------

.. autoclass:: alpaca.data.historical.screener.ScreenerClient
   :members: __init__


Get Most Actives
----------------

.. automethod:: alpaca.data.historical.screener.ScreenerClient.get_most_actives


Get Market Movers
-----------------

.. automethod:: alpaca.data.historical.screener.ScreenerClient.get_market_movers
