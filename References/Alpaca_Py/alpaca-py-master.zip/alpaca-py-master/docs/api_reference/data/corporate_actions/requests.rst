========
Requests
========


CorporateActionsRequest
-----------------------

.. autoclass:: alpaca.data.requests.CorporateActionsRequest
