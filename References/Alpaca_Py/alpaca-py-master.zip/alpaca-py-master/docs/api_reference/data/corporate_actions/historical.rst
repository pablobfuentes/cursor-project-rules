===============
Historical Data
===============


CorporateActionsClient
----------------------

.. autoclass:: alpaca.data.historical.corporate_actions.CorporateActionsClient
    :members: __init__


Get Corporate Actions
---------------------

.. automethod:: alpaca.data.historical.corporate_actions.CorporateActionsClient.get_corporate_actions
