========
Requests
========


BaseCryptoLatestDataRequest
---------------------------

.. autoclass:: alpaca.data.requests.BaseCryptoLatestDataRequest


CryptoBarsRequest
-----------------

.. autoclass:: alpaca.data.requests.CryptoBarsRequest


CryptoQuoteRequest
------------------

.. autoclass:: alpaca.data.requests.CryptoQuoteRequest


CryptoTradesRequest
-------------------

.. autoclass:: alpaca.data.requests.CryptoTradesRequest


CryptoLatestQuoteRequest
------------------------

.. autoclass:: alpaca.data.requests.CryptoLatestQuoteRequest


CryptoLatestTradeRequest
------------------------

.. autoclass:: alpaca.data.requests.CryptoLatestTradeRequest


CryptoSnapshotRequest
---------------------

.. autoclass:: alpaca.data.requests.CryptoSnapshotRequest
