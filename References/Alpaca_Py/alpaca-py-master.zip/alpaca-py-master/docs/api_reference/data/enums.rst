=====
Enums
=====


Exchange
--------

.. autoclass:: alpaca.data.enums.Exchange


DataFeed
--------

.. autoclass:: alpaca.data.enums.DataFeed


Adjustment
----------

.. autoclass:: alpaca.data.enums.Adjustment


CryptoFeed
----------

.. autoclass:: alpaca.data.enums.CryptoFeed


MostActivesBy
-------------

.. autoclass:: alpaca.data.enums.MostActivesBy


MarketType
----------

.. autoclass:: alpaca.data.enums.MarketType


CorporateActionsType
--------------------

.. autoclass:: alpaca.data.enums.CorporateActionsType
