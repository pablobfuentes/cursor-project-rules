========
Requests
========


BaseTimeseriesDataRequest
-------------------------

.. autoclass:: alpaca.data.requests.BaseTimeseriesDataRequest


BaseBarsRequest
---------------

.. autoclass:: alpaca.data.requests.BaseBarsRequest
