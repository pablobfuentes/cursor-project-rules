=========
TimeFrame
=========


TimeFrameUnit
-------------

.. autoenum:: alpaca.data.timeframe.TimeFrameUnit


TimeFrame
---------

.. autoclass:: alpaca.data.timeframe.TimeFrame
   :members:
   :undoc-members:
   :exclude-members: validate_timeframe, value, unit, amount, amount_value, unit_value
