=================
Corporate Actions
=================

The corporate actions endpoints allow you to retrieve data for splits, mergers, and other
corporate events.

Get Corporate Actions
---------------------

.. automethod:: alpaca.trading.client.TradingClient.get_corporate_announcements



Get  Corporate Action By ID
---------------------------

.. automethod:: alpaca.trading.client.TradingClient.get_corporate_announcement_by_id
