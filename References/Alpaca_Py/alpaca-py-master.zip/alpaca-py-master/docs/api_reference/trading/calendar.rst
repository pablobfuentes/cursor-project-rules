========
Calendar
========


The calendar endpoint allows you to view the market calendar. The market calendar contains a record
of all trading days.


Get Calendar
------------

.. automethod:: alpaca.trading.client.TradingClient.get_calendar
