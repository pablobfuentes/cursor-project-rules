=====
Clock
=====


The clock endpoint allows you to view the market clock. The market clock contains a record
of the trading hours for a given day.


Get Clock
---------

.. automethod:: alpaca.trading.client.TradingClient.get_clock
