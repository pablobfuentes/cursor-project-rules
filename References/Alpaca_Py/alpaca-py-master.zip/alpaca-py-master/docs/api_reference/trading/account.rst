=======
Account
=======


The account endpoint allow you to retrieve information about your account.


Get Account Details
-------------------

.. automethod:: alpaca.trading.client.TradingClient.get_account
