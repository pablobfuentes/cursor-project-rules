=============
TradingClient
=============

.. autoclass:: alpaca.trading.client.TradingClient
   :members: __init__
