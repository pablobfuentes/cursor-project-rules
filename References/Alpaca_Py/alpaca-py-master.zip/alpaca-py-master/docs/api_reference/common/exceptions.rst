Exceptions
----------

.. automodule:: alpaca.common.exceptions
   :members:
