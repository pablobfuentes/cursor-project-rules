=========
Positions
=========


Get All Open Positions For Account
----------------------------------

.. automethod:: alpaca.broker.client.BrokerClient.get_all_positions_for_account


Get A Open Position For Account
-------------------------------

.. automethod:: alpaca.broker.client.BrokerClient.get_open_position_for_account


Close All Positions For Account
-------------------------------

.. automethod:: alpaca.broker.client.BrokerClient.close_all_positions_for_account


Close A Position For Account
----------------------------

.. automethod:: alpaca.broker.client.BrokerClient.close_position_for_account
