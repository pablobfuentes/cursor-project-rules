=================
Portfolio History
=================


Get Portfolio History For Account
---------------------------------

.. automethod:: alpaca.broker.client.BrokerClient.get_portfolio_history_for_account
