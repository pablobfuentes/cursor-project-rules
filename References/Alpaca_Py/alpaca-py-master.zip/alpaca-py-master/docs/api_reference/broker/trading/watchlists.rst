==========
Watchlists
==========


Create a Watchlist For Account
------------------------------

.. automethod:: alpaca.broker.client.BrokerClient.create_watchlist_for_account


Get All Watchlists For Account
------------------------------

.. automethod:: alpaca.broker.client.BrokerClient.get_watchlists_for_account


Get Watchlist For Account By Id
-------------------------------

.. automethod:: alpaca.broker.client.BrokerClient.get_watchlist_for_account_by_id


Update Watchlist For Account By Id
----------------------------------

.. automethod:: alpaca.broker.client.BrokerClient.update_watchlist_for_account_by_id


Delete Watchlist From Account By Id
-----------------------------------

.. automethod:: alpaca.broker.client.BrokerClient.delete_watchlist_from_account_by_id


Add Asset To Watchlist For Account By Id
----------------------------------------

.. automethod:: alpaca.broker.client.BrokerClient.add_asset_to_watchlist_for_account_by_id


Remove Asset From Watchlist For Account By Id
---------------------------------------------

.. automethod:: alpaca.broker.client.BrokerClient.remove_asset_from_watchlist_for_account_by_id
