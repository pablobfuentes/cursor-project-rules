=========
Documents
=========


Get Trade Documents For Account
-------------------------------

.. automethod:: alpaca.broker.client.BrokerClient.get_trade_documents_for_account


Get Trade Document For Account By ID
------------------------------------

.. automethod:: alpaca.broker.client.BrokerClient.get_trade_document_for_account_by_id


Download Trade Document For Account By ID
-----------------------------------------

.. automethod:: alpaca.broker.client.BrokerClient.download_trade_document_for_account_by_id
