=======
Funding
=======


Create ACH Relationship For Account
-----------------------------------

.. automethod:: alpaca.broker.client.BrokerClient.create_ach_relationship_for_account


Get ACH Relationships For Account
---------------------------------

.. automethod:: alpaca.broker.client.BrokerClient.get_ach_relationships_for_account


Delete ACH Relationship For Account
-----------------------------------

.. automethod:: alpaca.broker.client.BrokerClient.delete_ach_relationship_for_account


Create Bank For Account
-----------------------

.. automethod:: alpaca.broker.client.BrokerClient.create_bank_for_account


Get Banks For Account
---------------------

.. automethod:: alpaca.broker.client.BrokerClient.get_banks_for_account


Delete Bank For Account
-----------------------

.. automethod:: alpaca.broker.client.BrokerClient.delete_bank_for_account


Create Transfer For Account
---------------------------

.. automethod:: alpaca.broker.client.BrokerClient.create_transfer_for_account


Get Transfers For Account
-------------------------

.. automethod:: alpaca.broker.client.BrokerClient.get_transfers_for_account


Cancel Transfer For Account
---------------------------

.. automethod:: alpaca.broker.client.BrokerClient.cancel_transfer_for_account
