Calendar
========

Get Market Calendar
-------------------

.. automethod:: alpaca.broker.client.BrokerClient.get_calendar
