======
Assets
======

With the asset methods, you can query the list of assets that are
available for trading and data consumption through Alpaca.


Get All Assets
--------------

.. automethod:: alpaca.broker.client.BrokerClient.get_all_assets


Get a Single Asset
------------------

.. automethod:: alpaca.broker.client.BrokerClient.get_asset
