=================
Corporate Actions
=================

The corporate actions endpoints allow you to retrieve data for splits, mergers, and other
corporate events.

Get Corporate Actions
---------------------

.. automethod:: alpaca.broker.client.BrokerClient.get_corporate_announcements



Get  Corporate Action By ID
---------------------------

.. automethod:: alpaca.broker.client.BrokerClient.get_corporate_announcement_by_id
