# placeholder for poetry-dynamic-versioning
__version__ = "0.0.0"
